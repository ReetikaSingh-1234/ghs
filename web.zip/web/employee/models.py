from django.db import models
import os





# Create your models here.
class Employee1(models.Model):
    name=models.CharField(max_length=50,null=False,blank=False)
    father_name=models.CharField(max_length=50,null=False,blank=False)
    hometown=models.CharField(max_length=50,null=False,blank=False)
    address=models.CharField(max_length=50,null=False,blank=False)
    
    contact_no=models.CharField(max_length=50,null=False,blank=True)
    adhaarcard=models.ImageField(upload_to="adhaarcard")
    
    def __str__(self):
        return self.name
        