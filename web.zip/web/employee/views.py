from django.shortcuts import render,HttpResponse
from .models import Employee1
from employee.models import Employee1
def index(request):
    return HttpResponse("this is home page")
def about(request):
    return HttpResponse("this is about page")
def services(request):
    return HttpResponse("this is services page")
def contact(request):
    return HttpResponse("this is contact page")
from django.shortcuts import render,HttpResponse

# Create your views here.
def index(request):
    return render(request,'about.html')
def about(request):
    return render(request,'services.html')

def services(request):
    return render(request,'about.html')
    
def employee(request):
    if request.method=="POST":
        obj=Employee1()
        obj.name=request.POST.get('name')
        
        obj.father_name=request.POST.get('father_name')
        obj.hometown=request.POST.get('hometown')
        obj.address=request.POST.get('address')
        
        obj.contact_no=request.POST.get('contact_no')
        
        obj.adhaarcard=request.POST.get('adhaarcard')
        
        
       
        if len(request.FILES)!=0:
                obj.adhaarcard=request.FILES['adhaarcard']
            
        obj.save()


    return render(request,'employee.html') 
def show(request):
    Employee2 = Employee1.objects.all
    return render(request, 'show.html',{'Employee2':Employee2})
