from django.apps import AppConfig


class Employee1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employee'
