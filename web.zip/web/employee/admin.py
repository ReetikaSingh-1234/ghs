from django.contrib import admin
from employee.models import Employee1
# Register your models here.
admin.site.register(Employee1)
